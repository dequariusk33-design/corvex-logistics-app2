const screens=[...document.querySelectorAll('.screen')];
const navItems=[...document.querySelectorAll('.nav-item')];
const toast=document.getElementById('toast');
const todayDate=document.getElementById('todayDate');
let deferredPrompt=null;
let selectedJobId=null;

const seedJobs=[
  {id:'CVX-2401',pickup:'West Metro Pharmacy',dropoff:'Lakeside Care Center',service:'STAT',handling:'Signature required',status:'Assigned',driver:'Jordan M.'},
  {id:'CVX-2402',pickup:'North Clinic',dropoff:'Central Lab',service:'Same-day',handling:'Temperature-sensitive',status:'Pending',driver:'Unassigned'},
  {id:'CVX-2398',pickup:'Community Pharmacy',dropoff:'Oakview Residence',service:'Routine',handling:'Standard',status:'Delivered',driver:'Taylor R.'}
];

function getJobs(){
  const raw=localStorage.getItem('corvex-demo-jobs');
  if(!raw){localStorage.setItem('corvex-demo-jobs',JSON.stringify(seedJobs));return [...seedJobs]}
  try{return JSON.parse(raw)}catch{return [...seedJobs]}
}
function saveJobs(jobs){localStorage.setItem('corvex-demo-jobs',JSON.stringify(jobs));renderAll()}
function esc(value=''){return String(value).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function showToast(message){toast.textContent=message;toast.classList.add('show');clearTimeout(showToast.t);showToast.t=setTimeout(()=>toast.classList.remove('show'),2200)}
function go(screen){
  screens.forEach(s=>s.classList.toggle('active',s.dataset.screen===screen));
  navItems.forEach(n=>n.classList.toggle('active',n.dataset.go===screen));
  history.replaceState(null,'',`#${screen}`);window.scrollTo({top:0,behavior:'smooth'});
  document.getElementById('app').focus({preventScroll:true});
}

document.addEventListener('click',e=>{const b=e.target.closest('[data-go]');if(b)go(b.dataset.go)});
window.addEventListener('hashchange',()=>{const s=location.hash.slice(1);if(screens.some(x=>x.dataset.screen===s))go(s)});

todayDate.textContent=new Intl.DateTimeFormat(undefined,{weekday:'short',month:'short',day:'numeric'}).format(new Date());

function badge(status,service){
  const cls=status==='Delivered'?'delivered':service==='STAT'?'stat':'';
  return `<span class="job-status ${cls}">${esc(status)}</span>`
}
function jobHtml(j,assignable=false){
  return `<article class="job-card">
    <button class="job-main" ${assignable?`data-assign="${esc(j.id)}"`:''} type="button">
      <div class="job-id">${esc(j.id)} · ${esc(j.service)}</div>
      <div class="job-route">${esc(j.pickup)} → ${esc(j.dropoff)}</div>
      <div class="job-meta">${esc(j.handling)}${j.driver?` · ${esc(j.driver)}`:''}</div>
    </button>${badge(j.status,j.service)}
  </article>`
}
function renderAll(){
  const jobs=getJobs();
  document.getElementById('customerJobs').innerHTML=jobs.map(j=>jobHtml(j)).join('');
  document.getElementById('dispatchJobs').innerHTML=jobs.map(j=>jobHtml(j,true)).join('');
  const active=jobs.filter(j=>j.status!=='Delivered').length, delivered=jobs.filter(j=>j.status==='Delivered').length, pending=jobs.filter(j=>j.status==='Pending').length;
  document.getElementById('metricActive').textContent=active;
  document.getElementById('metricDelivered').textContent=delivered;
  document.getElementById('metricPending').textContent=pending;
  document.getElementById('dispatchOpen').textContent=active;
  const d=jobs.find(j=>j.status==='Assigned')||jobs.find(j=>j.status!=='Delivered')||jobs[0];
  if(d){
    document.getElementById('driverJobId').textContent=d.id;
    document.getElementById('driverPriority').textContent=d.service;
    document.getElementById('driverPickup').textContent=d.pickup;
    document.getElementById('driverDropoff').textContent=d.dropoff;
    document.getElementById('driverHandling').textContent=d.handling.replace(' required','');
  }
}
renderAll();

document.getElementById('deliveryForm').addEventListener('submit',e=>{
  e.preventDefault();const fd=new FormData(e.currentTarget);const jobs=getJobs();
  const id=`CVX-${String(2403+Math.floor(Math.random()*700)).padStart(4,'0')}`;
  jobs.unshift({id,pickup:fd.get('pickup'),dropoff:fd.get('dropoff'),service:fd.get('service'),handling:fd.get('handling'),status:'Pending',driver:'Unassigned',notes:fd.get('notes')});
  saveJobs(jobs);e.currentTarget.reset();showToast(`${id} created in demo mode`);
});
document.getElementById('clearDemo').addEventListener('click',()=>{localStorage.setItem('corvex-demo-jobs',JSON.stringify(seedJobs));renderAll();showToast('Demo data reset')});

document.getElementById('dispatchJobs').addEventListener('click',e=>{
  const btn=e.target.closest('[data-assign]');if(!btn)return;selectedJobId=btn.dataset.assign;
  document.getElementById('assignJobTitle').textContent=`Assign ${selectedJobId}`;document.getElementById('assignDialog').showModal();
});
document.getElementById('confirmAssign').addEventListener('click',()=>{
  const jobs=getJobs(),driver=document.getElementById('driverSelect').value;const job=jobs.find(j=>j.id===selectedJobId);
  if(job){job.driver=driver;job.status=driver==='Unassigned'?'Pending':'Assigned';saveJobs(jobs);showToast(`${job.id} assigned to ${driver}`)}
  document.getElementById('assignDialog').close();
});

document.querySelectorAll('[data-status]').forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelectorAll('[data-status]').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
  const status=btn.dataset.status;document.getElementById('driverStatus').textContent=`Status updated: ${status}`;
  if(status==='Delivered'){
    const jobs=getJobs(),id=document.getElementById('driverJobId').textContent,job=jobs.find(j=>j.id===id);if(job){job.status='Delivered';saveJobs(jobs)}
  }
  showToast(`Driver status: ${status}`)
}));

document.getElementById('podBtn').addEventListener('click',()=>{
  const stamp=new Date().toLocaleString();document.getElementById('podResult').textContent=`Demo POD captured • ${stamp}`;showToast('Demo proof captured')
});
document.getElementById('locationBtn').addEventListener('click',()=>{
  const out=document.getElementById('podResult');
  if(!navigator.geolocation){out.textContent='Location is not supported on this device.';return}
  out.textContent='Requesting location permission…';
  navigator.geolocation.getCurrentPosition(pos=>{
    const lat=pos.coords.latitude.toFixed(4),lng=pos.coords.longitude.toFixed(4);out.textContent=`Location captured for demo: ${lat}, ${lng} • accuracy ±${Math.round(pos.coords.accuracy)}m`;showToast('Location captured')
  },()=>{out.textContent='Location permission was not granted.'},{enableHighAccuracy:true,timeout:8000,maximumAge:0});
});

function updateNetwork(){const online=navigator.onLine;const b=document.getElementById('networkBadge');b.textContent=online?'Online':'Offline';b.classList.toggle('offline',!online)}
window.addEventListener('online',updateNetwork);window.addEventListener('offline',updateNetwork);updateNetwork();

window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;document.getElementById('installBtn').hidden=false});
async function install(){
  if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;document.getElementById('installBtn').hidden=true;return}
  const isIOS=/iphone|ipad|ipod/i.test(navigator.userAgent);showToast(isIOS?'Safari: Share → Add to Home Screen':'Use your browser menu → Install app / Add to Home screen');
}
document.getElementById('installBtn').addEventListener('click',install);document.getElementById('installBtn2').addEventListener('click',install);
window.addEventListener('appinstalled',()=>showToast('Corvex installed'));

if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}

const start=location.hash.slice(1);if(start&&screens.some(x=>x.dataset.screen===start))go(start);

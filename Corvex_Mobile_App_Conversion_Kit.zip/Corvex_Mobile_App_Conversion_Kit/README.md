# Corvex Logistics — Mobile App Conversion Kit

This package turns the Corvex mobile experience into:
1. an installable PWA for iPhone/Android browsers; and
2. a Capacitor-ready project that can generate native iOS and Android projects.

## What already works in this package
- Mobile-first Corvex UI in red / navy / white
- PWA manifest + install icons + service worker/offline shell
- Customer delivery-creation demo
- Driver route/status/POD demo
- Browser geolocation demo
- Dispatch queue + demo driver assignment
- Local demo storage
- Privacy/terms placeholders
- Capacitor config for `com.corvexlogistics.app`

## Important: demo vs production
This is a functional MVP/demo shell, not a production healthcare system. It does **not** yet provide production authentication, server-enforced roles, encrypted healthcare data storage, real-time backend dispatch, native push notifications, audited chain of custody, or validated HIPAA compliance. Do not store PHI in the demo.

## A. Put the PWA online first
Upload the **contents of `www/`** to a secure HTTPS site such as:
- `app.corvexlogistics.xyz` (recommended), or
- a temporary Netlify/Vercel URL.

If you deploy at the root of a domain/subdomain, the manifest and service worker work as-is.

### Install on iPhone
Open the PWA URL in Safari → Share → **Add to Home Screen**.

### Install on Android
Open the PWA URL in Chrome → menu → **Install app** / **Add to Home screen**.

## B. Build the Android/iPhone wrappers
Install Node.js 20+ on your development computer, then in this folder run:

```bash
npm install
npx cap add android
npx cap add ios
npx cap sync
```

Open Android Studio:
```bash
npx cap open android
```

Open Xcode (macOS required):
```bash
npx cap open ios
```

Every time you edit files inside `www/`, run:
```bash
npx cap sync
```

## C. Before App Store / Google Play submission
Replace demo storage with a secure backend and authentication, add native capabilities only where needed, complete legal/privacy/security review, create production icons/screenshots, test on real devices, and sign the builds with your Apple/Google developer accounts.

## Recommended Corvex architecture
- `corvexlogistics.xyz` = public marketing website
- `app.corvexlogistics.xyz` = installable PWA/customer portal
- iOS + Android = Capacitor builds from this same `www/` codebase
- Future secure API/backend = deliveries, users, organizations, drivers, audit events, POD files and notifications

## Suggested production backend work
1. Authentication + organization/role authorization
2. Deliveries database + server-side status state machine
3. Driver assignment + live location service
4. Object storage for POD photos/signatures
5. Audit trail + exception logging
6. Push notifications
7. Maps/navigation provider
8. Security, privacy and compliance review before real healthcare data

## Brand/contact already used in the project
Public site: https://corvexlogistics.xyz
App ID: `com.corvexlogistics.app`

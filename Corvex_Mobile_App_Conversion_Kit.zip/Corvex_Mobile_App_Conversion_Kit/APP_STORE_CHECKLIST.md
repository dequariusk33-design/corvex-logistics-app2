# Corvex iOS submission checklist

- Apple Developer account
- Unique bundle ID: `com.corvexlogistics.app`
- App name and subtitle finalized
- Production privacy policy URL
- App privacy questionnaire completed from actual data practices
- App icons and screenshots for required device sizes
- Real functionality beyond a simple website wrapper
- Secure login/backend enabled for live operations
- Location permission copy only if location is actually used
- Camera/photo permission copy only if POD capture is actually used
- Background location only if truly necessary and justified
- TestFlight testing on real iPhone devices
- No claims of certification/compliance that Corvex has not formally achieved

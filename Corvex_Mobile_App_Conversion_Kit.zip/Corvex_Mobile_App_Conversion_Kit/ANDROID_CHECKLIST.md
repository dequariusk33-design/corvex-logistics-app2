# Corvex Android submission checklist

- Google Play Console developer account
- Application ID: `com.corvexlogistics.app`
- Signed Android App Bundle (.aab)
- Privacy policy URL
- Data safety form completed from actual data practices
- Store icon, feature graphic and screenshots
- Location/camera permissions limited to necessary workflows
- Internal/closed testing before production release
- Secure backend + authentication for live operations
- Target current required Android API level at submission time

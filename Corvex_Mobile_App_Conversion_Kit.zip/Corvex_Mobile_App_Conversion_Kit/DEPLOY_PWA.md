# Fastest PWA launch

## Recommended URL
`app.corvexlogistics.xyz`

## Netlify-style deployment
1. Create a new static site.
2. Upload the **contents of `www/`** (not the whole ZIP as a nested folder unless the host extracts it correctly).
3. Confirm `index.html` is at the deployed site root.
4. Add the custom domain `app.corvexlogistics.xyz`.
5. Add the DNS record your host gives you.
6. Wait for HTTPS to become active.
7. Open the URL on iPhone and Android and test installation.

## Verification
- `https://app.corvexlogistics.xyz/manifest.webmanifest` should load.
- Service worker should register on HTTPS.
- Add to Home Screen should launch without browser chrome.
- Test offline after one successful online load.
